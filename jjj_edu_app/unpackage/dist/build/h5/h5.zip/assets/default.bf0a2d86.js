const s="/h5/assets/default-b8775188.png";export{s as _};
