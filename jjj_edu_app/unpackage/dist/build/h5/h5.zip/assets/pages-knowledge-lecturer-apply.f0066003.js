import{_ as a,o as s,a as t,f as o}from"./index-911d5a8b.js";const e=a({data:()=>({}),methods:{}},[["render",function(a,e,n,r,d,f){const c=o;return s(),t(c)}]]);export{e as default};
