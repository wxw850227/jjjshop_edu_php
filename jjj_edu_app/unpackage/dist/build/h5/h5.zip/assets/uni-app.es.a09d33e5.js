import{a5 as r}from"./index-911d5a8b.js";function n(n,o){return r(n)?o:n}export{n as r};
